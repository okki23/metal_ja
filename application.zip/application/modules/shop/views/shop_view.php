<div class="banner-area banner-bg-head" style="background-image: url('<?php echo base_url(); ?>assets_front/images/workshop.png');">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="banner">
						<h2>Shop</h2>
						<ul class="page-title-link">
							<li><a href="#">Home</a></li>
							<li><a href="#">Shop</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>

    <div id="portfolio" class="section wb">
        <div class="container">
            <div class="section-title text-center">
                <h3>Penjualan PT Metal Jaya Abadi</h3>
                <p class="lead">Berikut ini adalah penjualan Plate kami</p>
            </div><!-- end title -->
        </div><!-- end container -->
        
        <hr class="invis">
            <!-- kumpuluan foto shering -->
        <div id="da-thumbs" class="da-thumbs portfolio">
            <div class="post-media pitem item-w1 item-h1 cat1">
                <a href="<?php echo base_url(); ?>assets_front/foto/bending_26.jpeg" data-rel="prettyPhoto[gal]">
                    <img src="<?php echo base_url(); ?>assets_front/foto/bending_26.jpeg" alt="" class="img-responsive">
                    <div>
                        <h3>Spesifikasi Mesin Shering <small>Web Design</small></h3>
                        <i class="flaticon-unlink"></i>
                    </div>
                </a>
            </div>
        </div><!-- end portfolio -->
    </div><!-- end container -->
</div><!-- end section -->
