<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_contact extends Parent_Model { 
   
 
}
