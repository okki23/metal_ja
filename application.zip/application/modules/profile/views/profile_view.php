<div class="banner-area banner-bg-head" style="background-image: url('<?php echo base_url(); ?>assets_front/images/workshop.png');">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="banner">
						<h2>Profile</h2>
						<ul class="page-title-link">
							<li><a href="#">Home</a></li>
							<li><a href="#">Profile</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
    </div>
    



    <div id="features" class="section wb">
        <div class="container">
            <div class="section-title text-center">
                <h3>Visi  & Misi</h3>
              
            </div><!-- end title -->

            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <ul class="features-left">
                        <li class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">
                            <i class="flaticon-line-graph"></i>
                            <div class="fl-inner">
                                <h4 style="text-align: center;">Menjadi Perusahaan Penyedia Jasa Yang Mampu bersaing di Pasaran </h4>
                            </div>
                        </li>
                        <li class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">
                            <i class="flaticon-line-graph"></i>
                            <div class="fl-inner">
                                <h4 style="text-align: center;">Mempertahankan Kualitas Menjadi Pokok Perhatian Pertama</h4>
                            </div>
                        </li>
                        <li class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">
                            <i class="flaticon-line-graph"></i>
                            <div class="fl-inner">
                                <h4 style="text-align: center;">Tetap Eksis di Dunia Pengolahan Plat Besi</h4>
                            </div>
                        </li>
                       
                    </ul>
                </div>
             
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <ul class="features-right">
                        <li class="wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s">
                            <i class="flaticon-line-graph"></i>
                            <div class="fr-inner">
                                <h4 style="text-align: center;">Meningkatkan Layanan Terhadap Konsumen </h4>
                            </div>
                        </li>
                        <li class="wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s">
                            <i class="flaticon-line-graph"></i>
                            <div class="fr-inner">
                                <h4 style="text-align: center;">Mengejar Target Produksi Agar Konsumen Puas dan Percaya </h4>
                            </div>
                        </li>
                        <li class="wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.4s">
                            <i class="flaticon-line-graph"></i>
                            <div class="fr-inner">
                                <h4 style="text-align: center;">Fokus dan Tetap Mengikuti Perkembangan Teknologi</h4>
                            </div>
                        </li>
                         
                    </ul>
                </div><!-- end col -->
            </div><!-- end row -->


            <div class="section-title text-center">
                <h3>Struktur</h3>
              
            </div><!-- end title -->

            <div class="row">
                
             <img src="images/struktur.png"> </img>

            </div><!-- end row -->


             
        </div><!-- end container -->
    </div><!-- end section -->
 